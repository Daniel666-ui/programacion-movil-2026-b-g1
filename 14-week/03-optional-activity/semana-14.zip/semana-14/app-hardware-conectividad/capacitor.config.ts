import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'co.edu.movil.hardware',
  appName: 'App Hardware',
  webDir: 'dist',
};

export default config;
