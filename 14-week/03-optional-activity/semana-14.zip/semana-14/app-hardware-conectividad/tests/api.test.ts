import { describe, it, expect, vi } from 'vitest';
import { createApi, ApiError, type TokenStore } from '../src/api';

function memoryStore(initial: string | null = null): TokenStore {
  let token = initial;
  return { get: () => token, set: (t) => { token = t; }, clear: () => { token = null; } };
}

const json = (status: number, body: unknown) =>
  new Response(JSON.stringify(body), { status, headers: { 'Content-Type': 'application/json' } });

describe('API con token', () => {
  it('cuando la petición protegida responde 401, borra el token y lanza "unauthorized"', async () => {
    const store = memoryStore('token-vencido');
    const fetchMock = vi.fn().mockResolvedValue(json(401, { message: 'Token Expired!' }));
    const api = createApi(store, fetchMock, () => true);

    const error = await api.getProfile().catch((e) => e);

    expect(error).toBeInstanceOf(ApiError);
    expect(error.kind).toBe('unauthorized');
    expect(store.get()).toBeNull();
    expect(fetchMock.mock.calls[0][1].headers.get('Authorization')).toBe('Bearer token-vencido');
  });

  it('sin red no hace la petición y lanza "offline"', async () => {
    const fetchMock = vi.fn();
    const api = createApi(memoryStore('t'), fetchMock, () => false);

    await expect(api.getProfile()).rejects.toMatchObject({ kind: 'offline' });
    expect(fetchMock).not.toHaveBeenCalled();
  });

  it('el login guarda el token devuelto por la API', async () => {
    const store = memoryStore();
    const api = createApi(store, vi.fn().mockResolvedValue(json(200, { accessToken: 'abc123' })), () => true);

    await api.login('emilys', 'emilyspass');

    expect(store.get()).toBe('abc123');
  });
});
