# App con hardware y conectividad — Corte 3

App móvil hecha con **Capacitor + Vite + TypeScript** (sin framework) que:

1. Usa el plugin **`@capacitor/camera`** para tomar fotos, verificando y pidiendo el **permiso de cámara**.
2. Consume una API con **login por token** y una **petición protegida**, manejando **401** y **sin red**.
3. Tiene **navegación clara** (pestañas Perfil / Cámara), los **tres estados** (carga / datos / error) y **pruebas unitarias**.

## API usada

[DummyJSON](https://dummyjson.com/docs/auth), API pública de prueba:

| Acción | Método y ruta | Notas |
|---|---|---|
| Login | `POST /auth/login` | Devuelve `accessToken` (dura 30 min) |
| Petición protegida | `GET /auth/me` | Requiere `Authorization: Bearer <token>`; sin token válido responde **401** |

Usuario de prueba: `emilys` / `emilyspass`.

## Estructura

```
src/
  api.ts       Cliente HTTP: login, token, petición protegida, 401, sin red, timeout
  camera.ts    Plugin de cámara + permisos
  ui.ts        Vistas de estado (carga / error) y aviso de sin conexión
  main.ts      Pantallas y navegación (login, perfil, cámara)
  style.css
tests/
  api.test.ts  Pruebas unitarias (Vitest)
android/       Proyecto nativo Android (permiso CAMERA en AndroidManifest.xml)
```

## Cómo ejecutarla

```bash
npm install
npm run dev        # en el navegador (http://localhost:5173)
npm test           # pruebas unitarias
npm run android    # build + sync + abre Android Studio para correrla en el celular
```

## Cómo probar cada requisito

- **Cámara y permisos:** pestaña *Cámara* → *Tomar foto*. La primera vez Android pide el permiso. Si se niega, la app muestra el estado de error con el mensaje para activarlo en Ajustes.
- **Token y 401:** al entrar, el perfil se carga con la petición protegida. El botón *Simular token vencido (401)* daña el token; la API responde 401, la app borra la sesión y vuelve al login con el aviso.
- **Sin red:** activa el modo avión y recarga el perfil. Aparece la franja "Sin conexión" y el estado de error con botón *Reintentar*.
- **Prueba unitaria:** `npm test` (3 pruebas: 401, sin red y guardado del token).

## Quality & connectivity

**Permissions.** Before opening the camera, the app calls `Camera.checkPermissions()` and only calls `Camera.requestPermissions()` when the user has not decided yet, so the system dialog never appears without a reason. The `CAMERA` permission is declared in `AndroidManifest.xml`, and the camera feature is marked as not required so the app can still be installed on devices without one. If the user denies the permission, the app does not crash or retry silently; it shows an error state explaining how to enable it from the device settings, and a cancelled photo simply returns the screen to its initial state.

**Token.** The login request (`POST /auth/login`) returns an access token that is stored locally and sent in the `Authorization: Bearer <token>` header on every protected request (`GET /auth/me`). When the server answers `401` (expired or invalid token), the API client deletes the stored token and the UI sends the user back to the login screen with a clear message, so the app never keeps working with a bad session. Login errors and session errors use different messages, and the profile screen includes a button that corrupts the token on purpose to demonstrate this flow.

**Errors.** All network calls go through a single `request()` function that classifies failures into four kinds: `unauthorized`, `offline`, `timeout` and `server`. The app checks `navigator.onLine` before sending a request, shows a red "no connection" banner that updates in real time, and aborts any request that takes longer than ten seconds. Every screen has three explicit states (loading, data and error), and each error state shows a human-readable message with a retry button instead of a technical stack trace. These behaviours are covered by unit tests with Vitest that mock `fetch` and the network status, verifying that a `401` clears the token and that no request is sent while offline.
