// Plugin de Capacitor: cámara, con verificación y solicitud de permisos.
import { Camera, CameraErrorCode } from '@capacitor/camera';
import { Capacitor } from '@capacitor/core';

export type PhotoResult =
  | { ok: true; src: string }
  | { ok: false; reason: 'denied' | 'cancelled' | 'no-camera' | 'error'; message: string };

// Revisa el permiso y lo pide solo si todavía no se ha decidido.
export async function ensureCameraPermission(): Promise<'granted' | 'denied'> {
  // En navegador el permiso lo pide el propio browser al abrir la cámara.
  if (!Capacitor.isNativePlatform()) return 'granted';

  let status = await Camera.checkPermissions();
  if (status.camera === 'prompt' || status.camera === 'prompt-with-rationale') {
    status = await Camera.requestPermissions({ permissions: ['camera'] });
  }
  return status.camera === 'granted' || status.camera === 'limited' ? 'granted' : 'denied';
}

export async function takePhoto(): Promise<PhotoResult> {
  const permission = await ensureCameraPermission();
  if (permission === 'denied') {
    return {
      ok: false,
      reason: 'denied',
      message: 'Sin permiso de cámara. Actívalo en Ajustes > Aplicaciones > Permisos.',
    };
  }

  try {
    const photo = await Camera.takePhoto({ quality: 80, correctOrientation: true });
    const src = photo.webPath ?? (photo.thumbnail ? `data:image/jpeg;base64,${photo.thumbnail}` : '');
    if (!src) return { ok: false, reason: 'error', message: 'No se pudo leer la foto.' };
    return { ok: true, src };
  } catch (err) {
    const code = (err as { code?: string }).code;
    const text = String((err as Error)?.message ?? err).toLowerCase();

    if (code === CameraErrorCode.CameraPermissionDenied || text.includes('denied') || text.includes('permission')) {
      return { ok: false, reason: 'denied', message: 'Permiso de cámara denegado.' };
    }
    if (code === CameraErrorCode.TakePhotoCancelled || text.includes('cancel')) {
      return { ok: false, reason: 'cancelled', message: 'Cancelaste la foto.' };
    }
    if (code === CameraErrorCode.NoCameraAvailable) {
      return { ok: false, reason: 'no-camera', message: 'Este dispositivo no tiene cámara disponible.' };
    }
    return { ok: false, reason: 'error', message: 'Ocurrió un error al abrir la cámara.' };
  }
}
