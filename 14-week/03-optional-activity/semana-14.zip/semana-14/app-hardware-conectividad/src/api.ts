// Cliente de la API: login por token, petición protegida y manejo de errores.
// API usada: DummyJSON (https://dummyjson.com/docs/auth), pública y gratuita.

export const API_URL = 'https://dummyjson.com';
const TOKEN_KEY = 'auth_token';
const TIMEOUT_MS = 10000;

export type ApiErrorKind = 'unauthorized' | 'offline' | 'timeout' | 'server';

export class ApiError extends Error {
  constructor(public kind: ApiErrorKind, message: string, public status?: number) {
    super(message);
    this.name = 'ApiError';
  }
}

export interface Profile {
  id: number;
  username: string;
  firstName: string;
  lastName: string;
  email: string;
  image: string;
}

// Almacenamiento del token (se puede inyectar otro en las pruebas).
export interface TokenStore {
  get(): string | null;
  set(token: string): void;
  clear(): void;
}

export const localTokenStore: TokenStore = {
  get: () => localStorage.getItem(TOKEN_KEY),
  set: (t) => localStorage.setItem(TOKEN_KEY, t),
  clear: () => localStorage.removeItem(TOKEN_KEY),
};

type FetchFn = typeof fetch;

export function createApi(
  store: TokenStore = localTokenStore,
  fetchFn: FetchFn = (...args) => fetch(...args),
  isOnline: () => boolean = () => navigator.onLine,
) {
  async function request<T>(path: string, init: RequestInit = {}, auth = false): Promise<T> {
    // 1) Sin red: no se intenta la petición.
    if (!isOnline()) {
      throw new ApiError('offline', 'No hay conexión a internet. Revisa tu red e inténtalo de nuevo.');
    }

    const headers = new Headers(init.headers);
    headers.set('Content-Type', 'application/json');
    if (auth) {
      const token = store.get();
      if (!token) throw new ApiError('unauthorized', 'Tu sesión no está iniciada.', 401);
      headers.set('Authorization', `Bearer ${token}`);
    }

    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);

    let res: Response;
    try {
      res = await fetchFn(`${API_URL}${path}`, { ...init, headers, signal: controller.signal });
    } catch (err) {
      // fetch solo falla así cuando no llega al servidor (sin red, DNS, CORS) o por timeout.
      if ((err as Error).name === 'AbortError') {
        throw new ApiError('timeout', 'El servidor tardó demasiado en responder.');
      }
      throw new ApiError('offline', 'No se pudo conectar con el servidor. Revisa tu conexión.');
    } finally {
      clearTimeout(timer);
    }

    // 2) Token inválido o vencido: se borra y se obliga a iniciar sesión otra vez.
    if (res.status === 401 || res.status === 403) {
      if (auth) store.clear();
      const msg = auth
        ? 'Tu sesión expiró. Inicia sesión de nuevo.'
        : 'Usuario o contraseña incorrectos.';
      throw new ApiError('unauthorized', msg, res.status);
    }

    // 3) Cualquier otro error del servidor.
    if (!res.ok) {
      throw new ApiError('server', `Error del servidor (${res.status}). Inténtalo más tarde.`, res.status);
    }

    return (await res.json()) as T;
  }

  return {
    isLoggedIn: () => store.get() !== null,

    async login(username: string, password: string): Promise<void> {
      const data = await request<{ accessToken?: string; token?: string }>('/auth/login', {
        method: 'POST',
        body: JSON.stringify({ username, password, expiresInMins: 30 }),
      });
      const token = data.accessToken ?? data.token;
      if (!token) throw new ApiError('server', 'La API no devolvió un token.');
      store.set(token);
    },

    // Petición protegida: solo responde con un token válido.
    getProfile: () => request<Profile>('/auth/me', {}, true),

    logout: () => store.clear(),

    // Solo para la demo: daña el token para provocar un 401 real.
    breakToken: () => {
      const t = store.get();
      if (t) store.set(t.slice(0, -5) + 'xxxxx');
    },
  };
}

export type Api = ReturnType<typeof createApi>;
