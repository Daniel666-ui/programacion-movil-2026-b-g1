import { defineCustomElements } from '@ionic/pwa-elements/loader';
import { ApiError, createApi, type Profile } from './api';
import { takePhoto } from './camera';
import { esc, loadingView, errorView, offlineBanner } from './ui';
import './style.css';

// Interfaz de cámara para cuando la app corre en el navegador.
defineCustomElements(window);

const api = createApi();
const app = document.querySelector<HTMLDivElement>('#app')!;

type Route = 'login' | 'perfil' | 'camara';

// ---------- Navegación ----------
function currentRoute(): Route {
  const r = location.hash.replace('#/', '') as Route;
  if (!api.isLoggedIn()) return 'login';
  return r === 'camara' || r === 'perfil' ? r : 'perfil';
}

function go(route: Route) {
  if (location.hash === `#/${route}`) render();
  else location.hash = `#/${route}`;
}

function shell(title: string, body: string, showNav = true): string {
  const route = currentRoute();
  return `
    ${offlineBanner(navigator.onLine)}
    <header class="topbar"><h1>${title}</h1>
      ${showNav ? '<button class="link" data-action="logout">Salir</button>' : ''}
    </header>
    <main class="content">${body}</main>
    ${showNav ? `
    <nav class="tabbar">
      <a href="#/perfil" class="${route === 'perfil' ? 'active' : ''}">👤<span>Perfil</span></a>
      <a href="#/camara" class="${route === 'camara' ? 'active' : ''}">📷<span>Cámara</span></a>
    </nav>` : ''}`;
}

// ---------- Login ----------
function renderLogin(error = '', loading = false) {
  app.innerHTML = shell('Iniciar sesión', `
    <form class="card" id="login-form">
      <p class="muted">Usuario de prueba de la API: <code>emilys</code> / <code>emilyspass</code></p>
      <label>Usuario<input name="username" autocomplete="username" value="emilys" required></label>
      <label>Contraseña<input name="password" type="password" autocomplete="current-password" value="emilyspass" required></label>
      ${error ? `<p class="error-text" role="alert">${esc(error)}</p>` : ''}
      <button class="btn" type="submit" ${loading ? 'disabled' : ''}>
        ${loading ? '<span class="spinner small"></span> Entrando…' : 'Entrar'}
      </button>
    </form>`, false);

  app.querySelector<HTMLFormElement>('#login-form')!.onsubmit = async (e) => {
    e.preventDefault();
    const form = new FormData(e.target as HTMLFormElement);
    renderLogin('', true);
    try {
      await api.login(String(form.get('username')), String(form.get('password')));
      go('perfil');
    } catch (err) {
      renderLogin(err instanceof ApiError ? err.message : 'Error inesperado.');
    }
  };
}

// ---------- Perfil (petición protegida) ----------
async function renderPerfil() {
  app.innerHTML = shell('Mi perfil', loadingView('Cargando tu perfil…'));
  try {
    const p: Profile = await api.getProfile();
    if (currentRoute() !== 'perfil') return;
    app.innerHTML = shell('Mi perfil', `
      <section class="card profile">
        <img src="${esc(p.image)}" alt="Foto de ${esc(p.firstName)}" width="96" height="96">
        <h2>${esc(p.firstName)} ${esc(p.lastName)}</h2>
        <p class="muted">@${esc(p.username)} · ${esc(p.email)}</p>
      </section>
      <section class="card">
        <h3>Probar manejo de errores</h3>
        <p class="muted">Daña el token guardado y vuelve a pedir el perfil: la API responde 401 y la app cierra la sesión.</p>
        <button class="btn secondary" data-action="break-token">Simular token vencido (401)</button>
      </section>`);
  } catch (err) {
    handleApiError(err, renderPerfil);
  }
}

function handleApiError(err: unknown, retry: () => void) {
  const e = err instanceof ApiError ? err : new ApiError('server', 'Error inesperado.');
  if (e.kind === 'unauthorized') {
    // 401: el token ya se borró en api.ts, volvemos al login con el aviso.
    location.hash = '#/login';
    renderLogin(e.message);
    return;
  }
  app.innerHTML = shell('Mi perfil', errorView(e.message, e.kind === 'offline' ? '📡' : '⚠️'));
  app.querySelector<HTMLButtonElement>('[data-action="retry"]')!.onclick = retry;
}

// ---------- Cámara (plugin + permisos) ----------
function renderCamara(state: 'idle' | 'loading' | 'photo' | 'error' = 'idle', data = '') {
  let body = '';
  if (state === 'idle') {
    body = `<div class="state">
      <div class="state-icon">📷</div>
      <p>Toma una foto con la cámara del dispositivo. La primera vez la app te pedirá permiso.</p>
      <button class="btn" data-action="photo">Tomar foto</button></div>`;
  } else if (state === 'loading') {
    body = loadingView('Abriendo la cámara…');
  } else if (state === 'photo') {
    body = `<section class="card">
      <img class="photo" src="${esc(data)}" alt="Foto tomada">
      <button class="btn" data-action="photo">Tomar otra</button></section>`;
  } else {
    body = errorView(data, '🚫', 'Intentar de nuevo');
  }
  app.innerHTML = shell('Cámara', body);
}

async function onTakePhoto() {
  renderCamara('loading');
  const result = await takePhoto();
  if (result.ok) renderCamara('photo', result.src);
  else if (result.reason === 'cancelled') renderCamara('idle');
  else renderCamara('error', result.message);
}

// ---------- Eventos globales ----------
app.addEventListener('click', (e) => {
  const action = (e.target as HTMLElement).closest<HTMLElement>('[data-action]')?.dataset.action;
  if (action === 'logout') { api.logout(); go('login'); }
  if (action === 'break-token') { api.breakToken(); renderPerfil(); }
  if (action === 'photo' || (action === 'retry' && currentRoute() === 'camara')) onTakePhoto();
});

function render() {
  const route = currentRoute();
  if (route === 'login') renderLogin();
  else if (route === 'perfil') renderPerfil();
  else renderCamara();
}

window.addEventListener('hashchange', render);
// Al cambiar la red se actualiza el aviso sin recargar la vista.
const updateBanner = () => {
  document.querySelector('.offline')?.remove();
  if (!navigator.onLine) app.insertAdjacentHTML('afterbegin', offlineBanner(false));
};
window.addEventListener('online', updateBanner);
window.addEventListener('offline', updateBanner);

render();
