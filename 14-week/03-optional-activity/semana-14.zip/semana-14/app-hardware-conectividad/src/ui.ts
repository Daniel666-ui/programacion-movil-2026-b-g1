// Componentes de los tres estados de la UI: carga, datos (en cada vista) y error.

export function esc(value: unknown): string {
  return String(value ?? '').replace(/[&<>"']/g, (c) =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]!,
  );
}

export function loadingView(text: string): string {
  return `<div class="state" aria-busy="true" aria-live="polite">
    <div class="spinner"></div><p>${esc(text)}</p></div>`;
}

export function errorView(message: string, icon = '⚠️', button = 'Reintentar'): string {
  return `<div class="state" role="alert">
    <div class="state-icon">${icon}</div>
    <p>${esc(message)}</p>
    <button class="btn" data-action="retry">${esc(button)}</button></div>`;
}

export function offlineBanner(online: boolean): string {
  return online ? '' : '<div class="offline" role="status">Sin conexión a internet</div>';
}
