package co.edu.movil.hardware;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
