# Proyecto: Gestión de Tareas Móviles

## Descripción
Aplicación móvil desarrollada con Ionic React que consume una API REST creada con Express.

## Ejecución Backend
cd backend
npm install
node server.js

## Ejecución Frontend
cd frontend
npm install
ionic serve

## Architecture

The project follows a client-server architecture composed of an Express REST API and an Ionic React mobile application. The backend provides two main endpoints: GET /tasks to retrieve the list of tasks and POST /tasks to create new tasks. The Ionic React application consumes these endpoints using the Fetch API to communicate with the server. The application uses React hooks such as useState to manage the local state and store the received data. Navigation is implemented to allow users to move from the task list screen to a task detail screen. Error handling is included to manage network failures and provide feedback to users when the API is unavailable.
