import { IonButton,IonContent,IonInput,IonItem,IonList,IonPage } from '@ionic/react';
import {useEffect,useState} from 'react';
import {useHistory} from 'react-router-dom';

export default function Home(){

const [tasks,setTasks]=useState<any[]>([]);
const [title,setTitle]=useState('');
const [error,setError]=useState('');
const history=useHistory();

const API='http://localhost:3000/tasks';

useEffect(()=>{
 fetch(API)
 .then(r=>r.json())
 .then(data=>setTasks(data))
 .catch(()=>setError('Error de conexión'));
},[]);

function createTask(){
 fetch(API,{
 method:'POST',
 headers:{'Content-Type':'application/json'},
 body:JSON.stringify({
  title,
  description:'Nueva tarea creada'
 })
 })
 .then(r=>r.json())
 .then(data=>setTasks([...tasks,data]))
 .catch(()=>setError('No fue posible crear'));
}

return <IonPage>
<IonContent>
<h1>Gestión de tareas</h1>

{error && <p>{error}</p>}

<IonList>
{tasks.map(t=>
<IonItem button key={t.id}
onClick={()=>history.push('/detail/'+t.id)}>
{t.title}
</IonItem>)}
</IonList>

<IonInput
placeholder="Nombre tarea"
value={title}
onIonChange={e=>setTitle(e.detail.value!)}
/>

<IonButton onClick={createTask}>
Crear tarea
</IonButton>

</IonContent>
</IonPage>
}
