import {IonContent,IonPage} from '@ionic/react';
import {useParams} from 'react-router-dom';

export default function Detail(){
const {id}=useParams<any>();

return <IonPage>
<IonContent>
<h1>Detalle de tarea</h1>
<p>ID seleccionado: {id}</p>
</IonContent>
</IonPage>
}
