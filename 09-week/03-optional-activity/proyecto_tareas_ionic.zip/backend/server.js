const express = require('express');
const cors = require('cors');

const app = express();

app.use(cors());
app.use(express.json());

let tasks = [
 {id:1,title:'Aprender Ionic',description:'Crear aplicación móvil'},
 {id:2,title:'Consumir API REST',description:'Usar Fetch'}
];

app.get('/tasks',(req,res)=>{
 res.json(tasks);
});

app.post('/tasks',(req,res)=>{
 const task={
  id:tasks.length+1,
  title:req.body.title,
  description:req.body.description
 };

 tasks.push(task);
 res.status(201).json(task);
});

app.get('/tasks/:id',(req,res)=>{
 const task=tasks.find(t=>t.id==req.params.id);
 if(!task) return res.status(404).json({error:'No encontrado'});
 res.json(task);
});

app.listen(3000,()=>console.log('API ejecutándose en puerto 3000'));
